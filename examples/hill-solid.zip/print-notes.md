# Print notes

Tuned for a Bambu Lab P2S (0.4 mm nozzle, textured PEI plate); PrusaSlicer works too.

## Recommended settings
- Nozzle 0.4 mm, layer height 0.16–0.20 mm
- 3+ wall loops (perimeters), 15–20% infill
- No supports where the overhang check passes; enable supports for high
  exaggeration or genuine cliffs (see validation-report.json → overhang).
- Pieces sit flat on their printed bottom; first-layer notes for textured plates apply.

## This model — separate-pieces
- Assembled footprint: 79.7 × 120.0 mm
- Pieces: 1 (1×1), base 3.0 mm, 1.8× exaggeration
- Separate pieces, connector clearance 0.2 mm per side.
- Print pieces individually or several per plate; assign a filament per piece for colour.
- **Print coupon.stl first** to confirm the tab/socket fit at your clearance.

## Calibration coupon
coupon.stl reproduces one tab + one socket at the exact
connector geometry and clearance/gap above. Adjust clearance and regenerate if the fit is off.
