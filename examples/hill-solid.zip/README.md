# TopoPuzzle Studio export

Place: custom bounds
Layout: 1×1 · separate-pieces · longest edge 120.0 mm

## Contents
- `*.stl` — one watertight STL per piece (labels A1…)
- `combined.stl` / `model.3mf` / `model.obj` — assembled reference (if selected)
- `coupon.stl` — connector calibration coupon (print this first)
- `color-changes.txt` — AMS filament-change Z heights per elevation band
- `settings.json` — the exact settings used (reproducible)
- `validation-report.json` — watertight / build-volume / overhang checks
- `attribution.txt` — elevation data source and license
- `print-notes.md` — slicer + printing guidance

Generated models belong to you (MIT).
