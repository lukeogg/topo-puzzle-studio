# Print notes

Tuned for a Bambu Lab P2S (0.4 mm nozzle, textured PEI plate); PrusaSlicer works too.

## Recommended settings
- Nozzle 0.4 mm, layer height 0.16–0.20 mm
- 3+ wall loops (perimeters), 15–20% infill
- No supports where the overhang check passes; enable supports for high
  exaggeration or genuine cliffs (see validation-report.json → overhang).
- Pieces sit flat on their printed bottom; first-layer notes for textured plates apply.

## This model — print-in-place
- Assembled footprint: 92.9 × 140.0 mm
- Pieces: 4 (2×2), base 3.0 mm, 1.8× exaggeration
- Print-in-place seam gap: 0.4 mm — prints as one plate and separates after printing.
- Seams are VISIBLE and pieces may need gentle flexing/deburring to free them.
- Connectors are straight-walled (no undercuts) so layers don't fuse.
- **Print coupon.stl first** to confirm the gap frees cleanly before the full plate.

## Calibration coupon
coupon.stl reproduces one tab + one socket at the exact
connector geometry and clearance/gap above. Adjust clearance and regenerate if the fit is off.
